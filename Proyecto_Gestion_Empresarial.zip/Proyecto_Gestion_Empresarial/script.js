function login() {
  const user = document.getElementById("user").value;
  const pass = document.getElementById("pass").value;
  const error = document.getElementById("error-msg");

  if (user === "admin" && pass === "1234") {
    window.location.href = "main.html";
  } else {
    error.textContent = "Usuario o contraseña incorrectos";
  }
}

function mostrar(modulo) {
  const secciones = document.querySelectorAll('.modulo');
  secciones.forEach(sec => sec.classList.remove('active'));
  document.getElementById(modulo).classList.add('active');
}
